import java.util.Scanner;

public class Principal {
    private CartaoDeCredito cartao;

   
    public Principal(String numero, String nomeTitular, String cpfTitular, float limiteInicial, float cashbackRate) {
        cartao = new CartaoDeCredito(numero, nomeTitular, cpfTitular, limiteInicial, cashbackRate);
    }

    
    public void consultarLimite() {
        System.out.printf("Limite disponível: R$%.2f%n", cartao.consultarLimite());
    }

   
    public void consultarSaldo() {
        System.out.printf("Saldo atual: R$%.2f%n", cartao.consultarSaldo());
    }

    
    public void realizarTransacao(float valor, boolean comCashback) {
        cartao.realizarTransacao(valor, comCashback);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

      
        System.out.println("Digite o número do cartão:");
        String numero = sc.nextLine();
        
        System.out.println("Digite o nome do titular:");
        String nomeTitular = sc.nextLine();
        
        System.out.println("Digite o CPF do titular:");
        String cpfTitular = sc.nextLine();
        
        System.out.println("Digite o limite de crédito:");
        float limiteInicial = sc.nextFloat();
        
        System.out.println("Digite a taxa de cashback (em decimal, ex: 0.05 para 5%):");
        float cashbackRate = sc.nextFloat();
        
        
        Principal programa = new Principal(numero, nomeTitular, cpfTitular, limiteInicial, cashbackRate);

        int opcao;
        do {
            System.out.println("\nEscolha uma opção:");
            System.out.println("1 - Realizar Transação");
            System.out.println("2 - Consultar Limite");
            System.out.println("3 - Consultar Saldo");
            System.out.println("0 - Sair");
            opcao = sc.nextInt();

            switch (opcao) {
                case 1:
                    System.out.println("Digite o valor da transação:");
                    float valor = sc.nextFloat();
                    System.out.println("Deseja incluir cashback na transação? (true/false)");
                    boolean comCashback = sc.nextBoolean();
                    programa.realizarTransacao(valor, comCashback);
                    break;
                case 2:
                    programa.consultarLimite();
                    break;
                case 3:
                    programa.consultarSaldo();
                    break;
                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        } while (opcao != 0);

        sc.close();
    }
}
